/* =====================================================
 * 
 *                      Yes Bike
 *
 * =====================================================
*/

#include <project.h>

    #define ACCEL_ADDR    (0x1D) //pg 19(DS)
    #define WHO_AM_I      (0x0D) //pg 21 or 30(DS)
    #define CTRL_REG1     (0x2A)  //pg 53
    
    #define OUT_X_MSB     (0x01)
    #define OUT_X_LSB     (0x02)
    #define OUT_Y_MSB     (0x03)
    #define OUT_Y_LSB     (0x04)
    #define OUT_Z_MSB     (0x05)
    #define OUT_Z_LSB     (0x06)
    
    #define PL_STATUS     (0x10)
    #define PL_CFG        (0x11)
    
    #define TRANSIENT_THS  (0x1F)
    #define TRANSIENT_COUNT (0x20)
    #define TRANSIENT_CFG    (0x1D)
    #define CTRL_REG4        (0x2D)
    #define CTRL_REG5         (0x2E)
    #define TRANSIENT_SRC     (0x1E)
        
    uint8 accel_ReadReg(uint8 Reg);
    void accel_WriteReg(uint8 Reg, uint8 value);

/* ===================================================
 * 
 * Credit to Kenneth Sy Su for his I2C/UART Tutorial
 *
 * ===================================================
*/