/* =====================================================
 * 
 *                      Yes Bike
 *
 * =====================================================
*/

#include <i2c.h>

//to read you must (1) Write the register address you want to read from to the slave device (accelerometer)
//                 (2) Use MasterReadBuf to store what is contained in the register into the read buffer

uint8 accel_ReadReg(uint8 Reg){
    uint8 Write_Buf[1]={0}; //Buffer that will contain the register that will be read from
    Write_Buf[0]=Reg;
    
    uint8 Read_Buf[1]={0};  //Buffer that will store the value read from the register
    
    //Step 1
    I2C_1_I2CMasterWriteBuf(ACCEL_ADDR, (uint8 *)Write_Buf, 1, I2C_1_I2C_MODE_NO_STOP);
    while((I2C_1_I2CMasterStatus() & I2C_1_I2C_MSTAT_WR_CMPLT)==0){}
    
    //Step 2
    I2C_1_I2CMasterReadBuf(ACCEL_ADDR, (uint8 *)Read_Buf, 1, I2C_1_I2C_MODE_REPEAT_START);
    while((I2C_1_I2CMasterStatus() & I2C_1_I2C_MSTAT_RD_CMPLT)==0){}
    
    
    
    return Read_Buf[0];
}

//to write, you want to write 2 values: (1) The register address that you want to write to
//                                      (2) The value you wish to write to the register

void accel_WriteReg(uint8 Reg, uint8 value){
    uint8 Write_Buf[2]={0};
    Write_Buf[0]=Reg;               //Assign the first element to be the register you want to write to (Parameter 1)
    Write_Buf[1]=value;             //Assign the second elemnt to be the value you wish to write to the register (Parameter 2)
    
    I2C_1_I2CMasterWriteBuf(ACCEL_ADDR, (uint8 *)Write_Buf, 2, I2C_1_I2C_MODE_COMPLETE_XFER);
    while((I2C_1_I2CMasterStatus()&I2C_1_I2C_MSTAT_WR_CMPLT)==0){}
    
    return;
}

/* ===================================================
 * 
 * Credit to Kenneth Sy Su for his I2C/UART Tutorial
 *
 * ===================================================
*/
