/* =====================================================
 * 
 *                      Yes Lock
 *
 * =====================================================
*/

#include <project.h>
#include <i2c.h>

uint8 connect = 0;          // Indicates if bluetooth is connected
uint8 restart = 0 ;         // Flag that turns on BLE advertisement
uint8 started = 0;          // Set on first write request from client 
uint8 i = 0;                // Keeps track of the number of hits/impacts

uint8 lock = 0;             // Determines if lock is unlocked/locked
uint8 alarm = 0;            // Determines if alarm is turned on/off
int alarmScanning = 0;      // Set when lock gets locked, starts alarm scanning

int warningNotify;          // Determines when bluetooth notifications are enabled 
uint8 warningState = 7;     // Determines what type of notification should be sent
uint8 warningStateOld;      // Stores previous warning state

// i =
// 3:   Sends warning notification through updateWarning()
// 6:   Sends warning notification through updateWarning()
// 10:  Sends alarm notification through updateWarning()
// Every 5 increments thereon after will send an alarm notification

// lock =
// 0:   Unlocks the servo motor (when 'Lock' switch disabled)
// 1:   Locks the servo motor (when 'Lock switch enabled)
    
// alarm =
// 0:   Turns off alarm (when 'OFF' button pressed)
// 1:   Turns on alarm (when 'ON' button pressed)
// 2:   Enables notification sending (when 'Lock' switch enabled)

// warningState =
// 1:   Send warning notification
// 2:   Send alarm notification
// 7:   Send no notifications (buffer)


/***************************************************************
 * Function to send warning and/or alarm notifications
 **************************************************************/
void updateWarning(uint8 whichWarnState)
{
    if(CyBle_GetState() != CYBLE_STATE_CONNECTED)
        return;

    warningState = whichWarnState;
    
    CYBLE_GATTS_HANDLE_VALUE_NTF_T tempHandle;
    
    // Only sends notification if it is a warning/alarm (not buffer)
    // and if the current state differs from the previous state
    if ((warningState==1 || warningState==2) && (warningState != warningStateOld)) 
    {
        // Stores value to send to client
        tempHandle.attrHandle = CYBLE_YESBIKE_WARNING_CHAR_HANDLE;
        tempHandle.value.val = (uint8 *) &warningState;
        tempHandle.value.len = 1;
        CyBle_GattsWriteAttributeValue(&tempHandle,0,&cyBle_connHandle,CYBLE_GATT_DB_LOCALLY_INITIATED);
        
        // Sends notification to client
        if (CyBle_GattGetBusyStatus() == CYBLE_STACK_STATE_FREE)
        {
            CyBle_GattsNotification(cyBle_connHandle,&tempHandle);
            CyBle_ProcessEvents();
        }        
    }
    
    // Stores current warning state to be next update's previous state
    warningStateOld = warningState;
}


/***************************************************************
 * Function to handle the BLE stack
 **************************************************************/
void StackEventHandler( uint32 eventCode, void *eventParam )
{
    CYBLE_GATTS_WRITE_REQ_PARAM_T *wrReqParam;
    
    switch( eventCode )
    {
        // Stack turns on (from a reset)
        case CYBLE_EVT_STACK_ON:
            restart = 1;       
            break;
        
        // Stack gets disconnected from client
        case CYBLE_EVT_GAP_DEVICE_DISCONNECTED: 
            restart = 1;
            break;
        
        case CYBLE_EVT_TIMEOUT:
            break;

        case CYBLE_EVT_GAP_DEVICE_CONNECTED:
            break;

        /* GAP Peripheral events */
        
        case CYBLE_EVT_GAPP_ADVERTISEMENT_START_STOP:
            if(CyBle_GetState() == CYBLE_STATE_DISCONNECTED)
                restart = 0;
            break;

        /* GATT events */
            
        // Connection made
        case CYBLE_EVT_GATT_CONNECT_IND:            
            connect = 1; 
            break;

        // Disconnection made
        case CYBLE_EVT_GATT_DISCONNECT_IND:
            connect = 0;
            break;

        // Handles a write request from client
        case CYBLE_EVT_GATTS_WRITE_REQ:
            wrReqParam = (CYBLE_GATTS_WRITE_REQ_PARAM_T *) eventParam;
        
            // Gets called when the 'Lock' switch on Android app is toggled
            if(wrReqParam->handleValPair.attrHandle == CYBLE_YESBIKE_LOCK_CHAR_HANDLE)
            {
                // Determines if servo motor should be unlocked or unlocked
                lock = wrReqParam->handleValPair.value.val[0];
                
                // Enables notification sending when 'Lock' switch gets enabled
                alarm = wrReqParam->handleValPair.value.val[1];
                
                // Sets flag when a switch gets toggled
                started = 1;              
                CyBle_GattsWriteRsp(cyBle_connHandle);                
			}            
            
            // Gets called when notifications are enabled ('Lock' switch enabled) by Android app
            if(wrReqParam->handleValPair.attrHandle == CYBLE_YESBIKE_WARNING_WARNINGCCCD_DESC_HANDLE)
            {
                // Writes into GATT server what the client wrote
                CyBle_GattsWriteAttributeValue(&wrReqParam->handleValPair, 0, &cyBle_connHandle, CYBLE_GATT_DB_PEER_INITIATED);
                
                // Retrieves from GATT server what the client wrote
                warningNotify = wrReqParam->handleValPair.value.val[0];
                
                // Acknowledges that the attribute has been successfully written
                CyBle_GattsWriteRsp(cyBle_connHandle);
            }
            
            // Gets called when the alarm 'ON' or 'OFF' button on Android app is pressed
            if(wrReqParam->handleValPair.attrHandle == CYBLE_YESBIKE_ALARM_CHAR_HANDLE)
            {
                alarm = wrReqParam->handleValPair.value.val[0];
                CyBle_GattsWriteRsp(cyBle_connHandle);
			}
            
			break; 
        
        default:
            break;
    }
} 


// Interrupt handler for accelerometer that increments the number 
// of hits/impacts and causes the alarm buzzer to beep/remain on
CY_ISR(Acc_Handler)
{
    Pin_2_ClearInterrupt();
    
    if (alarmScanning == 1)
    {
        i=i+1;
        PWM_1_WriteCompare(125);    // Buzzer on
        green_Write(0);             // LED on
        CyDelay(500);
        
        // Buzzer beeps when number of hits is less than 10,
        // otherwise leave alarm buzzer on when i >= 10
        if (i<10)
        {
            PWM_1_WriteCompare(0);  // Buzzer off
            green_Write(1);         // LED off
        }
    }
}

// Interrupt handler that resets the number of hits when the
// five second timer times out only when the alarm isn't on
CY_ISR(Timer_Handler)
{
    if (PWM_1_ReadCapture() != 125)     // Alarm isn't on
    {
        i = 0;
    }
}

// Interrupt handler that resets software (configured to easily
// reset software when there are bluetooth connection issues)
CY_ISR(Reset_Handler)
{
    Pin_5_ClearInterrupt();
    CySoftwareReset();
}

int main()
{
    CyGlobalIntEnable; 
    
    /* Bluetooth + Components' Initializations */
    
    CyBle_Start(StackEventHandler);
    
    Timer_1_Start();
    Timer_ISR_StartEx(Timer_Handler);
    
    PWM_1_Start();                  // Controls alarm buzzer
    PWM_2_Start();                  // Controls servo motor
    PWM_2_WriteCompare(216);        // Servo unlock
    
    I2C_1_Start();
    isr_1_StartEx(Acc_Handler);     // Interrupt handler for accelerometer
    isr_2_StartEx(Reset_Handler);   // Interrupt handler for software reset

    /* Configuration of accelerometer using I2C protocol */
    
    uint8 deviceID;
    uint8 CtrlReg1_beforeWrite,CtrReg1_afterWrite;
    uint8 status, cfgbefore,cfgafter,status1;
    uint8 trans;
    
    cfgbefore=accel_ReadReg(PL_CFG);
    accel_WriteReg(CTRL_REG1, 0x00);
    accel_WriteReg(PL_CFG, 0b11000000);
    cfgafter=accel_ReadReg(PL_CFG);
    
    CtrlReg1_beforeWrite=accel_ReadReg(CTRL_REG1);
    accel_WriteReg(TRANSIENT_THS, 0x85);
    accel_WriteReg(TRANSIENT_COUNT, 0x02);
    accel_WriteReg(TRANSIENT_CFG, 0b00010110);
    accel_WriteReg(CTRL_REG4, 0x20);
    accel_WriteReg(CTRL_REG5, 0x20);
    accel_WriteReg(CTRL_REG1, 0x29);
    CtrReg1_afterWrite=accel_ReadReg(CTRL_REG1);
          
    for(;;)
    {
        // Retrieves accelerometer values from device register
        deviceID = accel_ReadReg(WHO_AM_I);
        status = accel_ReadReg(PL_STATUS);
        trans = accel_ReadReg(TRANSIENT_SRC);
        
        // BLE connected
        if(connect == 1)
        {
            blue_Write(1);
            if(started == 1)
            {                
                // Unlocks the servo motor...
                if (lock == 0)
                {   
                    alarmScanning = 0;              // Alarm scanning off
                    PWM_2_WriteCompare(216);        // Servo unlock
                    
                    red_Write(1);
                    green_Write(1);
                    blue_Write(1);
                }
                // Locks the servo motor...
                else if(lock == 1)
                {
                    alarmScanning = 1;              // Alarm scanning on
                    PWM_2_WriteCompare(226);        // Servo lock                  
                }
            }
        }
        else
        {
            blue_Write(!blue_Read());               // Indicates bluetooth not connected
            CyDelay(500);
        }
                                        
        if(alarmScanning == 1) 
        {
            if (alarm == 1)
            {
                PWM_1_WriteCompare(125);        // Alarm on
                green_Write(0);
            }
            else if (alarm == 0)
            {
                PWM_1_WriteCompare(0);          // Alarm off
                PWM_2_WriteCompare(216);        // Servo unlock
                green_Write(1);
                alarmScanning = 0;              // Turn off alarm scanning
                i = 0;                          // Reset number of hits
            }
            else if (alarm == 2)
            {
                // Sends warning notification to user...
                if (i==3 || i==6)
                {
                    updateWarning(1);                
                }
                // Sends alarm notification to user + turns on alarm...
                else if ((i>9) && (i%5==0))
                {
                    PWM_1_WriteCompare(125);
                    green_Write(0);                
                    updateWarning(2);                    
                }
                // Sends no notifications (buffer)...
                else
                {                
                    updateWarning(7);
                }
            }           
        }
        
        // Upon bluetooth initialization/disconnection, turn on advertisement
        if(restart == 1)
        {
            restart = 0;
            CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
        }
        
        // Required to frequently check BLE stack handler
        CyBle_ProcessEvents();
    }
}
